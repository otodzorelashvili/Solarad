import React from 'react'

const UpVoteIcon = ({ active }) => (
  <svg
    width="24px"
    height="24px"
    viewBox="0 0 24 24"
    xmlns="http://www.w3.org/2000/svg"
    fill={active ? '#e3613d' : 'none'}
    stroke={active ? '#e3613d' : 'currentColor'}
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M12.781 2.375c-.381-.475-1.181-.475-1.562 0l-8 10A1.001 1.001 0 0 0 4 14h4v7a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-7h4a1.001 1.001 0 0 0 .781-1.625l-8-10zM15 12h-1v8h-4v-8H6.081L12 4.601 17.919 12H15z" />
  </svg>
)

const DownVoteIcon = ({ active }) => (
  <svg
    width="24px"
    height="24px"
    viewBox="0 0 24 24"
    xmlns="http://www.w3.org/2000/svg"
    fill={active ? '#e3613d' : 'none'}
    stroke={active ? '#e3613d' : 'currentColor'}
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M20.901 10.566A1.001 1.001 0 0 0 20 10h-4V3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v7H4a1.001 1.001 0 0 0-.781 1.625l8 10a1 1 0 0 0 1.562 0l8-10c.24-.301.286-.712.12-1.059zM12 19.399 6.081 1" />
  </svg>
)

const VoteButtons = ({ currentVote, onVote, upCount, downCount }) => {
  const handleUpClick = () => {
    console.log('UpVote button clicked, currentVote:', currentVote)
    if (currentVote === 'up') {
      onVote(null)
    } else {
      onVote('up')
    }
  }

  const handleDownClick = () => {
    console.log('DownVote button clicked, currentVote:', currentVote)
    if (currentVote === 'down') {
      onVote(null)
    } else {
      onVote('down')
    }
  }

  return (
    <div className="vote-buttons">
      <button
        aria-label="Up Vote"
        className={`vote-button upvote ${currentVote === 'up' ? 'active' : ''}`}
        onClick={handleUpClick}
        type="button"
      >
        <UpVoteIcon active={currentVote === 'up'} />
        <span className="vote-count">{Number(upCount) || 0}</span>
      </button>
      <button
        aria-label="Down Vote"
        className={`vote-button downvote ${currentVote === 'down' ? 'active' : ''}`}
        onClick={handleDownClick}
        type="button"
      >
        <DownVoteIcon active={currentVote === 'down'} />
        <span className="vote-count">{Number(downCount) || 0}</span>
      </button>
    </div>
  )
}

export default VoteButtons
