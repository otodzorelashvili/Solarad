import { createClient } from '@supabase/supabase-js'

// Replace these with your own Supabase project URL and anon key
const supabaseUrl = 'https://fbnvezxtjyupilmayxfc.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZibnZlenh0anl1cGlsbWF5eGZjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM0NTM1NjcsImV4cCI6MjA2OTAyOTU2N30.RX7N0V69PN9ywO2TDIfqyIC4Uve0ouX2TzC37I_hnUg   '

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
