import { useState, useEffect } from 'react';
import { supabase } from './supabaseClient';
import './App.css';

// Modal Component - You can put this in a separate file (e.g., components/Modal.js)
// For simplicity, I'm including it here.
const Modal = ({ children, isOpen, onClose, title }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{title}</h2>
          <button className="modal-close-button" onClick={onClose}>
            &times;
          </button>
        </div>
        <div className="modal-body">{children}</div>
      </div>
    </div>
  );
};

function App() {
  const [ads, setAds] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [siteUrl, setSiteUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [view, setView] = useState('ads');
  const [user, setUser] = useState(null);
  const [selectedAd, setSelectedAd] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);

  // Modal specific states
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  // NEW: State for the Post Ad Modal
  const [isPostAdModalOpen, setIsPostAdModalOpen] = useState(false);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [choice, setChoice] = useState('digital');
  const [address, setAddress] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Fetch ads on view or user change
  useEffect(() => {
    if (view === 'ads' || view === 'admin') fetchAds();
  }, [view, user]);

  // Monitor user authentication status
  useEffect(() => {
    const getUser = async () => {
      const { data } = await supabase.auth.getUser();
      setUser(data.user);
      if (data.user) checkAdmin(data.user.id);
    };

    getUser();

    const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
      const loggedInUser = session?.user || null;
      setUser(loggedInUser);
      if (loggedInUser) checkAdmin(loggedInUser.id);
    });

    return () => {
      listener?.subscription?.unsubscribe?.();
    };
  }, []);

  // Check admin role
  async function checkAdmin(userId) {
    const { data, error } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', userId)
      .single();

    if (!error && data?.role === 'admin') setIsAdmin(true);
    else setIsAdmin(false);
  }

  // Fetch ads from the database
  async function fetchAds() {
    setLoading(true);
    setError(null);

    if (!user) {
      const { data, error } = await supabase
        .from('ads')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) setError(error.message);
      else setAds(data);

      setLoading(false);
      return;
    }

    const { data: adsData, error: adsError } = await supabase
      .from('ads')
      .select(
        `
        *,
        ad_likes:ad_likes (
          user_id
        ),
        ad_votes:ad_votes (
          user_id,
          vote_type
        )
        `
      )
      .order('created_at', { ascending: false });

    if (adsError) {
      setError(adsError.message);
      setLoading(false);
      return;
    }

    const processedAds = adsData.map((ad) => {
      const likes = ad.ad_likes || [];
      const votes = ad.ad_votes || [];
      const likesCount = likes.length;
      const likedByUser = user ? likes.some((like) => like.user_id === user.id) : false;
      const votesArray = Array.isArray(votes) ? votes : [];
      const upVotes = votesArray.filter((v) => v.vote_type === 'up');
      const downVotes = votesArray.filter((v) => v.vote_type === 'down');
      const upCount = upVotes.length;
      const downCount = downVotes.length;
      const userVoteObj = user ? votesArray.find((v) => v.user_id === user.id) : null;
      const userVote = userVoteObj ? userVoteObj.vote_type : null;

      return { ...ad, likesCount, likedByUser, upCount, downCount, userVote };
    });

    setAds(processedAds);
    setLoading(false);
  }

  // Handle like/unlike an ad (unchanged)
  async function handleLike(adId, liked) {
    if (!user) {
      setError('რეკლამის მოწონებისთვის საჭიროა ავტორიზაცია.');
      return;
    }
    setError(null);

    if (liked) {
      const { error } = await supabase
        .from('ad_likes')
        .delete()
        .match({ ad_id: adId, user_id: user.id });

      if (error) {
        setError(error.message);
        return;
      }
    } else {
      const { error } = await supabase
        .from('ad_likes')
        .insert([{ ad_id: adId, user_id: user.id }]);

      if (error) {
        setError(error.message);
        return;
      }
    }

    fetchAds();
  }

  // Handle voting (up/down) for an ad (unchanged)
  async function handleVote(adId, voteType) {
    if (!user) {
      setError('ხმის მიცემისთვის საჭიროა ავტორიზაცია.');
      return;
    }
    setError(null);

    const existingVote = ads.find((ad) => ad.id === adId)?.userVote;

    setAds((prevAds) =>
      prevAds.map((ad) => {
        if (ad.id !== adId) return ad;
        let newUp = ad.upCount;
        let newDown = ad.downCount;
        let newUserVote = ad.userVote;

        if (existingVote === voteType) {
          if (voteType === 'up') newUp = Math.max(0, newUp - 1);
          else if (voteType === 'down') newDown = Math.max(0, newDown - 1);
          newUserVote = null;
        } else {
          if (existingVote === 'up') newUp = Math.max(0, newUp - 1);
          else if (existingVote === 'down') newDown = Math.max(0, newDown - 1);
          if (voteType === 'up') newUp++;
          else if (voteType === 'down') newDown++;
          newUserVote = voteType;
        }

        return { ...ad, upCount: newUp, downCount: newDown, userVote: newUserVote };
      })
    );

    if (existingVote === voteType) {
      const { error } = await supabase
        .from('ad_votes')
        .delete()
        .match({ ad_id: adId, user_id: user.id });
      if (error) setError(error.message);
    } else if (existingVote) {
      const { error } = await supabase
        .from('ad_votes')
        .update({ vote_type: voteType })
        .match({ ad_id: adId, user_id: user.id });
      if (error) setError(error.message);
    } else {
      const { error } = await supabase
        .from('ad_votes')
        .insert([{ ad_id: adId, user_id: user.id, vote_type: voteType }]);
      if (error) setError(error.message);
    }

    fetchAds();
  }

  // Add new ad (now also closes the modal)
  async function handleSubmit(e) {
    e.preventDefault();
    if (!title || !description) return setError('გთხოვთ შეიყვანოთ სათაური და აღწერა');

    setLoading(true);
    setError(null);

    const { data: userData } = await supabase.auth.getUser();
    const currentUser = userData?.user;
    if (!currentUser) {
      setError('რეკლამის განთავსებისთვის საჭიროა ავტორიზაცია.');
      setLoading(false);
      return;
    }

    const { error } = await supabase
      .from('ads')
      .insert([{ title, description, photo_url: photoUrl, site_url: siteUrl }]);

    if (error) setError(error.message);
    else {
      setTitle('');
      setDescription('');
      setPhotoUrl('');
      setSiteUrl('');
      setIsPostAdModalOpen(false); // Close the modal after successful submission
      setView('ads'); // Go back to ads view after posting
      fetchAds();
    }

    setLoading(false);
  }

  // User Registration
  async function handleRegister(e) {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    if (!companyName) return setError('კომპანიის სახელი სავალდებულოა');
    if (!email) return setError('ელ.ფოსტა სავალდებულოა');
    if (!password) return setError('პაროლი სავალდებულოა');
    if (password !== confirmPassword) return setError('პაროლები არ ემთხვევა');
    if (choice === 'physical' && !address) return setError('მისამართი სავალდებულოა');

    setLoading(true);

    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: 'http://localhost:3000',
      },
    });

    if (signUpError) {
      setError(signUpError.message);
      setLoading(false);
      return;
    }

    const userId = data?.user?.id || data?.session?.user?.id;
    if (!userId) {
      setError('ვერ მოიძებნა იუზერის ID');
      setLoading(false);
      return;
    }

    const { error: profileError } = await supabase.from('company_profiles').insert([
      {
        id: userId,
        company_name: companyName,
        company_email: email,
        choice,
        address: choice === 'physical' ? address : null,
      },
    ]);

    if (profileError) {
      setError(profileError.message);
      setLoading(false);
      return;
    }

    setSuccessMessage('რეგისტრაცია წარმატებულია, გადაამოწმეთ ელფოსტა.');
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setCompanyName('');
    setChoice('digital');
    setAddress('');
    setLoading(false);
    // You might want to keep the registration modal open with a success message for a bit.
    // Or close it and automatically log them in / redirect.
    // For now, let's just close it.
    setIsRegisterModalOpen(false);
  }

  // User Login
  async function handleLogin(e) {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    if (!email || !password) return setError('შეავსეთ ყველა ველი');

    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
      setError(error.message);
      setLoading(false);
      return;
    }

    setSuccessMessage('შესვლა წარმატებულია!');
    setEmail('');
    setPassword('');
    setLoading(false);
    setIsLoginModalOpen(false); // Close login modal on successful login
    setView('ads'); // Go to ads view after login
  }

  // User Logout (unchanged)
  async function handleLogout() {
    setLoading(true);
    await supabase.auth.signOut();
    setUser(null);
    setView('ads');
    setLoading(false);
  }

  // Input change handler (unchanged)
  function handleInputChange(setter) {
    return (e) => {
      setError('');
      setSuccessMessage('');
      setter(e.target.value);
    };
  }

  // Admin delete ad (unchanged)
  async function handleDeleteAd(adId) {
    const confirmed = await new Promise((resolve) => {
      const result = window.confirm('ნამდვილად გსურს რეკლამის წაშლა?');
      resolve(result);
    });

    if (!confirmed) return;

    const { error } = await supabase.from('ads').delete().eq('id', adId);

    if (error) {
      setError(error.message);
    } else {
      fetchAds();
    }
  }

  return (
    <div className="App">
      <nav className="nav-bar">
        <div className="site-name">
          Solar<span style={{ color: '#e3613d' }}>AD</span>
        </div>
        <div className="nav-buttons">
          <button
            onClick={() => {
              setView('ads');
              // Close all modals when navigating to 'ads' view
              setIsLoginModalOpen(false);
              setIsRegisterModalOpen(false);
              setIsPostAdModalOpen(false);
            }}
            disabled={loading}
            className={view === 'ads' ? 'active' : ''}
            style={{ minHeight: '47px' }}
          >
            რეკლამები
          </button>
          {/* Modified: Button to open Post Ad Modal */}
          <button
            onClick={() => {
              // Only open the post ad modal if the user is logged in
              if (user) {
                setIsPostAdModalOpen(true);
              } else {
                setError('რეკლამის გამოქვეყნებისთვის საჭიროა ავტორიზაცია.');
              }
            }}
            disabled={loading}
            // Apply cursor style based on user login status
            style={{ minHeight: '47px', cursor: user ? 'pointer' : 'not-allowed' }}
            title={user ? '' : 'რეკლამის გამოქვეყნებისთვის საჭიროა ავტორიზაცია.'} // Tooltip
          >
            გამოქვეყნება
          </button>
          {!user ? (
            <>
              {/* Button to open Login Modal */}
              <button
                onClick={() => {
                  setIsLoginModalOpen(true);
                  // Close other modals if open
                  setIsRegisterModalOpen(false);
                  setIsPostAdModalOpen(false);
                }}
                className='otar1'
                disabled={loading}
                style={{ minHeight: '47px' }}
              >
                ავტორიზაცია
              </button>
            </>
          ) : (
            <>
              {/* Admin button only if isAdmin is true */}
              {isAdmin && (
                <button
                  onClick={() => {
                    setView('admin');
                    // Close all modals when navigating to 'admin' view
                    setIsLoginModalOpen(false);
                    setIsRegisterModalOpen(false);
                    setIsPostAdModalOpen(false);
                  }}
                  disabled={loading}
                  className={view === 'admin' ? 'active' : ''}
                  style={{ minHeight: '47px' }}
                >
                  ადმინისტრაცია
                </button>
              )}
              <button onClick={handleLogout} disabled={loading} className='otar1' style={{ minHeight: '47px' }}>
                გასვლა
              </button>
            </>
          )}
        </div>
      </nav>

      {view === 'ads' && (
        <>
          <header className="hero-section">
            <h1>
              კეთილი იყოს თქვენი მობრძანება Solar
              <span style={{ color: '#e3613d' }}>AD</span>-ზე
            </h1>
            <p className="oto">ატვირთე შენი სტარტაპის რეკლამა და მოიზიდე საზოგადოება ...</p>
            {/* Modified: CTA button to open Post Ad Modal */}
            <button
              className="cta-button"
              onClick={() => {
                if (user) {
                  setIsPostAdModalOpen(true);
                } else {
                  setError('რეკლამის გამოქვეყნებისთვის საჭიროა ავტორიზაცია.');
                }
              }}
              style={{ minHeight: '47px', cursor: user ? 'pointer' : 'not-allowed' }}
              title={user ? '' : 'რეკლამის გამოქვეყნებისთვის საჭიროა ავტორიზაცია.'} // Tooltip
            >
              რეკლამის გამოქვეყნება
            </button>
          </header>

          {loading && ads.length === 0 ? (
            <p>იტვირთება...</p>
          ) : ads.length === 0 ? (
            <p>რეკლამა არ არის.</p>
          ) : (
            <div className="ads-grid">
              {ads.map((ad) => (
                <div key={ad.id} className="ad-card">
                  {ad.photo_url ? (
                    <img src={ad.photo_url} alt={ad.title} className="ad-photo" />
                  ) : (
                    <div className="no-photo-placeholder">
                      <svg width="100px" height="100px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 11C3 7.22876 3 5.34315 4.17157 4.17157C5.34315 3 7.22876 3 11 3H13C16.7712 3 18.6569 3 19.8284 4.17157C21 5.34315 21 7.22876 21 11V13C21 16.7712 21 18.6569 19.8284 19.8284C18.6569 21 16.7712 21 13 21H11C7.22876 21 5.34315 21 4.17157 19.8284C3 18.6569 3 16.7712 3 13V11Z" stroke="#33363f3b" strokeWidth="2" />
                        <path fillRule="evenodd" clipRule="evenodd" d="M18.9997 13.5854L18.9794 13.5651C18.5898 13.1754 18.2537 12.8393 17.9536 12.5864C17.6367 12.3193 17.2917 12.0845 16.8665 11.9562C16.3014 11.7857 15.6986 11.7857 15.1335 11.9562C14.7083 12.0845 14.3633 12.3193 14.0464 12.5864C13.7463 12.8393 13.4102 13.1754 13.0206 13.5651L12.9921 13.5936C12.6852 13.9004 12.5046 14.0795 12.3645 14.1954L12.3443 14.2118L12.3317 14.1891C12.2447 14.0295 12.1435 13.7961 11.9726 13.3972L11.9191 13.2726L11.8971 13.2211L11.897 13.221C11.5411 12.3904 11.2422 11.693 10.9464 11.1673C10.6416 10.6257 10.2618 10.1178 9.66982 9.82106C9.17604 9.57352 8.6235 9.46711 8.07311 9.51356C7.41323 9.56924 6.87197 9.89977 6.38783 10.2894C5.98249 10.6157 5.52754 11.0598 5 11.5859V12.9999C5 13.5166 5.0003 13.9848 5.00308 14.411L6.117 13.2971C6.80615 12.6079 7.26639 12.1497 7.64186 11.8475C8.01276 11.5489 8.17233 11.5123 8.24128 11.5065C8.42475 11.491 8.60893 11.5265 8.77352 11.609C8.83539 11.64 8.96994 11.7333 9.20344 12.1482C9.43981 12.5682 9.69693 13.1646 10.0809 14.0605L10.1343 14.1851L10.1506 14.2232C10.2995 14.5707 10.4378 14.8936 10.5759 15.1468C10.7206 15.412 10.9308 15.7299 11.2847 15.9489C11.702 16.2072 12.1997 16.3031 12.6831 16.2182C13.093 16.1463 13.4062 15.9292 13.6391 15.7367C13.8613 15.5529 14.1096 15.3045 14.3769 15.0371L14.377 15.0371L14.4063 15.0078C14.8325 14.5816 15.1083 14.307 15.3353 14.1157C15.5526 13.9325 15.6552 13.8878 15.7112 13.8709C15.8995 13.8141 16.1005 13.8141 16.2888 13.8709C16.3448 13.8878 16.4474 13.9325 16.6647 14.1157C16.8917 14.307 17.1675 14.5816 17.5937 15.0078L18.9441 16.3582C18.9902 15.6404 18.9983 14.7479 18.9997 13.5854Z" fill="#33363f3b" />
                        <circle cx="16.5" cy="7.5" r="1.5" fill="#33363f3b" />
                      </svg>
                    </div>
                  )}
                  <h3
                    className="ad-title-link"
                    onClick={() => {
                      setSelectedAd(ad);
                      setView('postDetail');
                    }}
                    style={{ cursor: 'pointer', color: '#e3613d', textDecoration: 'underline' }}
                  >
                    {ad.title}
                  </h3>
                  <p>{ad.description.slice(0, 100)}...</p>
                  <small>{new Date(ad.created_at).toLocaleString()}</small>
                </div>
              ))}
            </div>
          )}

          {/* New Services Section */}
          <div className="services-section" style={{
            padding: '40px 20px',
            backgroundColor: '#f9f9f9',
            textAlign: 'center',
            marginTop: '40px',
            borderRadius: '8px',
            boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
          }}>
            <h2 style={{ color: '#333', marginBottom: '30px' }}>ჩვენი სერვისები</h2>
            <div style={{
              display: 'flex',
              justifyContent: 'space-around',
              flexWrap: 'wrap',
              gap: '20px'
            }}>
              <div className="service-item" style={{
                flex: '1 1 300px',
                padding: '20px',
                backgroundColor: '#fff',
                borderRadius: '8px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
                minWidth: '280px'
              }}>
                <h3 style={{ color: '#e3613d', marginBottom: '10px' }}>ციფრული რეკლამა</h3>
                <p>თქვენ შეგიძლიათ ჩვენს საიტზე ატვირთოთ ნებისმიერი სახის რეკლამა ...</p>
              </div>
              <div className="service-item" style={{
                flex: '1 1 300px',
                padding: '20px',
                backgroundColor: '#fff',
                borderRadius: '8px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
                minWidth: '280px'
              }}>
                <h3 style={{ color: '#e3613d', marginBottom: '10px' }}>ფიზიკური რეკლამა</h3>
                <p>ტრადიციული მარკეტინგული გადაწყვეტილებები ბიზნესის ფიზიკური წარმოდგენისთვის.</p>
              </div>
              <div className="service-item" style={{
                flex: '1 1 300px',
                padding: '20px',
                backgroundColor: '#fff',
                borderRadius: '8px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
                minWidth: '280px'
              }}>
                <h3 style={{ color: '#e3613d', marginBottom: '10px' }}>სარეკლამო ანალიტიკა</h3>
                <p>დეტალური ანგარიშები და ანალიზი თქვენი კამპანიის ეფექტურობის გასაუმჯობესებლად.</p>
              </div>
            </div>
          </div>
        </>
      )}

      {/* This 'post' view is now redundant if using a modal, but kept for context.
          It will no longer be rendered directly by changing 'view' state to 'post'.
          Instead, the modal state 'isPostAdModalOpen' controls its visibility.
      {view === 'post' && (
        <form onSubmit={handleSubmit} className="form-box">
          <h2>ახალი რეკლამის დამატება</h2>
          <input
            className="input"
            placeholder="სათაური"
            value={title}
            onChange={handleInputChange(setTitle)}
          />
          <textarea
            className="textarea"
            placeholder="აღწერა"
            value={description}
            onChange={handleInputChange(setDescription)}
          />
          <input
            className="input"
            placeholder="ფოტოს URL (არასავალდებულო)"
            value={photoUrl}
            onChange={handleInputChange(setPhotoUrl)}
          />
          <input
            className="input"
            placeholder="საიტის URL (არასავალდებულო)"
            value={siteUrl}
            onChange={handleInputChange(setSiteUrl)}
          />
          <button className="button" type="submit" disabled={loading} style={{ minHeight: '47px' }}>
            {loading ? 'იტვირთება...' : 'დამატება'}
          </button>
          {error && <p className="error">{error}</p>}
        </form>
      )}
      */}

      {view === 'postDetail' && selectedAd && (
        <div className="post-detail">
          <button className="back-button" onClick={() => setView('ads')} style={{ minHeight: '47px' }}>
            უკან დაბრუნება
          </button>
          {selectedAd.photo_url && (
            <img src={selectedAd.photo_url} alt={selectedAd.title} className="detail-photo" />
          )}
          <h2 className="h2">{selectedAd.title}</h2>
          <p>{selectedAd.description}</p>
          <small>გამოქვეყნდა: {new Date(selectedAd.created_at).toLocaleString()}</small>
          {selectedAd.site_url && (
            <p style={{ marginTop: '1rem' }}>
              საიტის ბმული:{' '}
              <a
                href={selectedAd.site_url}
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: '#e3613d', textDecoration: 'underline' }}
              >
                {selectedAd.site_url}
              </a>
            </p>
          )}
        </div>
      )}

      {/* Admin Page */}
      {view === 'admin' && isAdmin && (
        <div className="admin-page">
          <h2>ადმინისტრაციის პანელი</h2>
          {loading ? (
            <p>იტვირთება...</p>
          ) : ads.length === 0 ? (
            <p>რეკლამები არ არის.</p>
          ) : (
            <table className="admin-table" style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={{ border: '1px solid #ccc', padding: '8px' }}>ID</th>
                  <th style={{ border: '1px solid #ccc', padding: '8px' }}>სათაური</th>
                  <th style={{ border: '1px solid #ccc', padding: '8px' }}>აღწერა</th>
                  <th style={{ border: '1px solid #ccc', padding: '8px' }}>ფოტო URL</th>
                  <th style={{ border: '1px solid #ccc', padding: '8px' }}>საიტის URL</th>
                  <th style={{ border: '1px solid #ccc', padding: '8px' }}>შექმნის თარიღი</th>
                  <th style={{ border: '1px solid #ccc', padding: '8px' }}>მოქმედება</th>
                </tr>
              </thead>
              <tbody>
                {ads.map((ad) => (
                  <tr key={ad.id}>
                    <td style={{ border: '1px solid #ccc', padding: '8px' }}>{ad.id}</td>
                    <td style={{ border: '1px solid #ccc', padding: '8px' }}>{ad.title}</td>
                    <td style={{ border: '1px solid #ccc', padding: '8px' }}>{ad.description}</td>
                    <td style={{ border: '1px solid #ccc', padding: '8px' }}>{ad.photo_url || '—'}</td>
                    <td style={{ border: '1px solid #ccc', padding: '8px' }}>{ad.site_url || '—'}</td>
                    <td style={{ border: '1px solid #ccc', padding: '8px' }}>
                      {new Date(ad.created_at).toLocaleString()}
                    </td>
                    <td style={{ border: '1px solid #ccc', padding: '8px' }}>
                      <button
                        onClick={() => handleDeleteAd(ad.id)}
                        style={{
                          backgroundColor: '#e3613d',
                          color: 'white',
                          border: 'none',
                          padding: '6px 12px',
                          cursor: 'pointer',
                          minHeight: '47px'
                        }}
                        disabled={loading}
                      >
                        წაშლა
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {error && <p className="error">{error}</p>}
        </div>
      )}

      {/* Login Modal */}
      <Modal
        isOpen={isLoginModalOpen}
        onClose={() => {
          setIsLoginModalOpen(false);
          setError(null); // Clear errors when closing modal
          setSuccessMessage(null); // Clear success message
        }}
        title="ავტორიზაცია"
      >
        <form onSubmit={handleLogin} className="form-box">
          <h2>ავტორიზაცია</h2>

          <input
            className="input"
            type="email"
            placeholder="ელ.ფოსტა"
            value={email}
            onChange={handleInputChange(setEmail)}
          />
          <input
            className="input"
            type="password"
            placeholder="პაროლი"
            value={password}
            onChange={handleInputChange(setPassword)}
          />
          <button className="button" type="submit" disabled={loading} style={{ minHeight: '47px' }}>
            {loading ? 'იტვირთება...' : 'შესვლა'}
          </button>
          {error && <p className="error">{error}</p>}
          {successMessage && <p className="success">{successMessage}</p>}
          <p className="form-link">
            არ გაქვთ ანგარიში?{' '}
            <span
              onClick={() => {
                setIsLoginModalOpen(false);
                setIsRegisterModalOpen(true);
                setError(null); // Clear errors when switching forms
                setSuccessMessage(null); // Clear success message
              }}
              style={{ cursor: 'pointer', color: '#e3613d', textDecoration: 'underline' }}
            >
              რეგისტრაცია
            </span>
          </p>
        </form>
      </Modal>

      {/* Register Modal */}
      <Modal
        isOpen={isRegisterModalOpen}
        onClose={() => {
          setIsRegisterModalOpen(false);
          setError(null); // Clear errors when closing modal
          setSuccessMessage(null); // Clear success message
        }}
        title="რეგისტრაცია"
      >
        <form onSubmit={handleRegister} className="form-box">
          <h2>კომპანიის რეგისტრაცია</h2>

          <input
            className="input"
            placeholder="კომპანიის სახელი"
            value={companyName}
            onChange={handleInputChange(setCompanyName)}
          />
          <input
            className="input"
            type="email"
            placeholder="ელ.ფოსტა"
            value={email}
            onChange={handleInputChange(setEmail)}
          />
          <input
            className="input"
            type="password"
            placeholder="პაროლი"
            value={password}
            onChange={handleInputChange(setPassword)}
          />
          <input
            className="input"
            type="password"
            placeholder="გაიმეორეთ პაროლი"
            value={confirmPassword}
            onChange={handleInputChange(setConfirmPassword)}
          />
          <div className="radio-group">

            <label>
              <input
                type="radio"
                value="digital"
                checked={choice === 'digital'}
                onChange={() => setChoice('digital')}
              />{' '}
              ციფრული
            </label>
            <label>
              <input
                type="radio"
                value="physical"
                checked={choice === 'physical'}
                onChange={() => setChoice('physical')}
                disabled={loading} // Disable during loading
              />{' '}
              ფიზიკური
            </label>
          </div>
          {choice === 'physical' && (
            <input
              className="input"
              placeholder="მისამართი"
              value={address}
              onChange={handleInputChange(setAddress)}
            />
          )}
          <button className="button" type="submit" disabled={loading} style={{ minHeight: '47px' }}>
            {loading ? 'იტვირთება...' : 'რეგისტრაცია'}
          </button>
          {error && <p className="error">{error}</p>}
          {successMessage && <p className="success">{successMessage}</p>}
          <p className="form-link">
            უკვე გაქვთ ანგარიში?{' '}
            <span
              onClick={() => {
                setIsRegisterModalOpen(false);
                setIsLoginModalOpen(true);
                setError(null); // Clear errors when switching forms
                setSuccessMessage(null); // Clear success message
              }}
              style={{ cursor: 'pointer', color: '#e3613d', textDecoration: 'underline' }}
            >
              შესვლა
            </span>
          </p>
        </form>
      </Modal>

      {/* NEW: Post Ad Modal */}
      <Modal
        isOpen={isPostAdModalOpen}
        onClose={() => {
          setIsPostAdModalOpen(false);
          setError(null); // Clear errors when closing modal
          // Clear form fields when closing the modal without submitting
          setTitle('');
          setDescription('');
          setPhotoUrl('');
          setSiteUrl('');
        }}
        title="ახალი რეკლამის დამატება"
      >
        <form onSubmit={handleSubmit} className="form-box">
          <h2>რეკლამის ატვირთვა</h2>

          <input
            className="input"
            placeholder="სათაური"
            value={title}
            onChange={handleInputChange(setTitle)}
          />
          <textarea
            className="textarea"
            placeholder="აღწერა"
            value={description}
            onChange={handleInputChange(setDescription)}
          />
          <input
            className="input"
            placeholder="ფოტოს URL (არასავალდებულო)"
            value={photoUrl}
            onChange={handleInputChange(setPhotoUrl)}
          />
          <input
            className="input"
            placeholder="საიტის URL (არასავალდებულო)"
            value={siteUrl}
            onChange={handleInputChange(setSiteUrl)}
          />
          <button className="button" type="submit" disabled={loading} style={{ minHeight: '47px' }}>
            {loading ? 'იტვირთება...' : 'დამატება'}
          </button>
          {error && <p className="error">{error}</p>}
        </form>
      </Modal>

      <footer className="footer">
        <p>© 2024 SolarAd. ყველა უფლება დაცულია.</p>
      </footer>
    </div>
  );
}

export default App;